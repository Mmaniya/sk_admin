 <?php 
 function main() { 
   
 
 if($_POST['act']=='addEditUsers') {  
 ob_clean();
 $params = array('username','password','user_type','contact_fname','contact_lname','contact_email','contact_address','contact_city','contact_country','contact_phone','skype_id','phone','timezone');
 foreach($params as $K=>$V) {  $param[$V]=$$V=check_input($_POST[$V]); } 
  
 
  $arrayEmpType = $_POST['employee_type'];
  $empTypes = implode(",", $arrayEmpType);
  
  $param['employee_type'] =$empTypes;
  
  $contact_country = $_POST['contact_country'];
  
  if($contact_country=='United States') { $param['contact_state']= $_POST['us_state'];   } else {   $param['contact_state']= $_POST['contact_state'];  }
  
  $param['business_email']= trim($_POST['business_email']);
  if($_POST['joined_date']!='')
  $param['joined_date'] = date('Y-m-d',strtotime($_POST['joined_date']));
  
  if($_POST['id']=='') {           
	 
	
 //timeline ->	estimated time to complete
	//ques new 
	//table dom_import_simplexmlid,doc name,docu type doc desc
	$param['added_date'] = date('Y-m-d H:i:s',time());		
	$param['added_by']= $_SESSION['user_id'];  
	echo $rsDtls = Table::insertData(array('tableName'=>TBL_USERS,'fields'=>$param,'showSql'=>'N')); 
	$explode = explode('::',$rsDtls);  $serviceId = $explode[2];
 }
	else { 
 $param['last_updated'] = date('Y-m-d H:i:s',time());		
  //$param['last_updated_by']= $_SESSION['user_id'];  
 $where= array('id'=>$_POST['id']);
 echo  Table::updateData(array('tableName'=>TBL_USERS,'fields'=>$param,'where'=>$where,'showSql'=>'N'));
		 
	}
		 
 exit(); }
 
 
   if($_POST['act']=='show_add_edit_users') {
 ob_clean();
include 'add_edit_users.php'; 	   
 exit();
   }
 
 
 
 if($_POST['act']=='deleteUser') {
		ob_clean();
		$param['last_updated'] = date('Y-m-d H:i:s',time());		
		//$param['last_updated_by']= $_SESSION['user_id'];  
		$param['status']= 'I';  
		$where= array('id'=>$_POST['id']);
		echo Table::updateData(array('tableName'=>TBL_USERS,'fields'=>$param,'where'=>$where,'showSql'=>'N'));
	 exit();	
	}
//PAGE_LIMIT
 
 if($_POST['act']=='show_users_list') {
  ob_clean();

    $userObj = new Users();
    $rsUsers = $userObj->getUsersList();
		 
	if($_POST['page']=='')	$page=1;	else	$page = $_POST['page'];
	$totalCount = count($rsUsers);
	$totalPages= ceil(($totalCount)/(PAGE_LIMIT));
	if($totalPages==0) $totalPages=1;
	$StartIndex= ($page-1)*PAGE_LIMIT;
	if(count($rsUsers)>0) $listingArr = array_slice($rsUsers,$StartIndex,PAGE_LIMIT,true);
	
      include 'users_list.php'; 	  
	
  exit();
   }
   
   
   if($_POST['act']=='checkUsername') {
	   ob_clean();
	   $username = $_POST['username'];
		$param = array('tableName'=>TBL_USERS,'fields'=>array('*'),'condition'=>array('username'=>$username.'-CHAR'));
		$rsUsers = Table::getData($param);	
		echo count($rsUsers);
	   exit();
   }
   
    if($_POST['act']=='checkEmail') {
	   ob_clean();
	   $contact_email = $_POST['contact_email'];
		$param = array('tableName'=>TBL_USERS,'fields'=>array('*'),'condition'=>array('contact_email'=>$contact_email.'-CHAR'),'showSql'=>'Y');
		$rsUsers = Table::getData($param);	
		echo count($rsUsers);
	   exit();
   }
   
   if($_POST['act']=='show_users') { ob_clean();
   include 'view_user.php';
   exit();
   }
   
    if($_POST['act']=='changeUserPassword') { ob_clean();
   include 'change_user_password.php';
   exit();
   }
   
   if($_POST['act']=='UpdateUserPassword') {
   ob_clean();
   $param['password'] = $_POST['password'];
   $param['last_updated'] = date('Y-m-d H:i:s',time());		
   $where= array('id'=>$_POST['id']);
 echo  Table::updateData(array('tableName'=>TBL_USERS,'fields'=>$param,'where'=>$where,'showSql'=>'N'));
		 
  exit();  }
  
  
     if($_POST['act']=='showChangeEmail') { ob_clean();
   include 'change_user_email.php';
   exit();
   }
  
  if($_POST['act']=='changeUserEmail') {
   ob_clean();
   $param['contact_email'] = $_POST['contact_email'];
   $param['last_updated'] = date('Y-m-d H:i:s',time());		
   $where= array('id'=>$_POST['id']);
 echo  Table::updateData(array('tableName'=>TBL_USERS,'fields'=>$param,'where'=>$where,'showSql'=>'N'));
		 
  exit();  }
  
  
    if($_POST['act']=='showChangeUsername') { 
	ob_clean();
      include 'change_user_username.php';
    exit();
   }
   
  
   if($_POST['act']=='changeUserUsername') {
   ob_clean();
   $param['username'] = $_POST['username'];
   $param['last_updated'] = date('Y-m-d H:i:s',time());		
   $where= array('id'=>$_POST['id']);
 echo  Table::updateData(array('tableName'=>TBL_USERS,'fields'=>$param,'where'=>$where,'showSql'=>'N'));
		 
  exit();  }
  
  
  
		 
   
 
 ?>  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
						<div class="row">
						<div class="col-sm-12">
							<div class="page-title-box">
								<h4 class="page-title">Users</h4>
								<ol class="breadcrumb float-right">
									<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Users </li>
								</ol>
								<div class="clearfix"></div>
							</div>
						</div>
						</div>


                        <div class="row">
                            <div class="col-lg-7">
                                <div class="card-box">
								<div class="row">
								<div class="col-lg-6"><h4 class="m-t-0 header-title">Users Details</h4></div>
                                    <?php if($_SESSION['user_type']!='E' && $_SESSION['user_type']!='FL') {?>
								<div class="col-lg-6"><a href="javascript:void(0)" onclick="showAddEditForm(0,'<?php echo $_REQUEST['isMMS']?1:0;?>')" style="float:right">Add New</a></div>
                                    <?php } ?>
                                      </div>
                                  
								   <div class="table_div"></div>
								   
                                </div>

                            </div>

                            <div class="col-lg-5">

                               <span class="right_bar_div"></span>

                            </div>
                        </div> 
       <script src='assets/js/jquery.inputmask.bundle.js'></script>              
<script> 

function showChangeUsername(id) {
	paramData = {'act':'showChangeUsername','id':id};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		    $('.right_bar_div').html(data);              	  
		}});	
}

function showChangeEmail(id) {
	paramData = {'act':'showChangeEmail','id':id};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		    $('.right_bar_div').html(data);              	  
		}});	
}


function changePassword(id) { $('#con-close-modal').modal('hide');
	paramData = {'act':'changeUserPassword','id':id};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		    $('.right_bar_div').html(data);              	  
		}});	
}


function viewUsers(id) {
	paramData = {'act':'show_users','id':id};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		  $('.modal-popup').html(data); 
            $('#con-close-modal').modal('show'); 		  
		}});	
}


function showAddEditForm(id,isMMS) {
  $('#con-close-modal').modal('hide');

	paramData = {'act':'show_add_edit_users','id':id,'isMMS':isMMS};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		  $('.right_bar_div').html(data);			  
		}});	
}

 show_user_list();
function show_user_list() {
	paramData = {'act':'show_users_list'};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		  $('.table_div').html(data);			  
		}});	
}


function deleteUsers(id) {
	if(confirm('Are you sure you want to delete this user?')) {
	paramData = {'act':'deleteUser','id':id};
	ajax({ 
		a:'users',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		show_user_list();
var res = data.split("::");
alert(res[1]);		 
		}});	
} }
 


  
</script>
  
					
 <?php } include 'template.php'; ?>