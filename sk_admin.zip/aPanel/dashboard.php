 <?php 
 
 
 
 function main() { 
 
 		 $invoiceObj = new Invoice();
		 $invoiceObj->reportType='month';
		 $invoiceObj->month =date('n',time());
		 $stats=$invoiceObj->getSalesStatistics();
		 $statArr = explode('::',$stats);
     $percent='40%';
echo '<div style="width:40%"><div width="100%" style="background-color:#ccc"><div style="width:'.$percent.';background-color:#039cfd;height:35px;\">&nbsp;</div></div></div>';
     /*$param = array('tableName'=>'logs','fields'=>array('*'),'condition'=>array('id'=>'15-INT'),'showSql'=>'N');
     $rsRecords = Table::getData($param);
     echo urldecode($rsRecords->description);*/
 ?> 
             
        <div class="row">
        <div class="col-sm-12">
        <div class="page-title-box">
        <h4 class="page-title">Welcome  <?php echo $_SESSION['name']; ?>!</h4>
        <ol class="breadcrumb float-right">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
        <div class="clearfix"></div>
        </div>
        </div>
        </div>
        
        <div class="row">
        <div class="col-lg-8">
        <h4 id="stat_heading" class="pb-3">
        Report for Month of  <?php echo date('F',time()); ?></h4>
        </div>
        </div>
        
        <div class="row">
        <div class="col-md-2">
        <strong>Select Report Type: </strong>
        </div>
        <div class="col-md-4">  
        
        <select id="reportType" name="reportType" onchange="showOptions()">
        <option value="month" selected>Monthly Report</option>
        <option value="date">DayWise Report</option>
        <option value="range">Date Range Report</option>
        <option value="all">All Time Report</option>
        </select>
        
        </div>
        </div>
        
        <div class="row reportOptions pt-3" id="month_div">
        <div class="col-md-2">  </div>
        <div class="col-md-2">  
        
        
        <?php  $currentMonth = date('n',time()); ?>
        <select name="monthValue" id="monthValue" onchange="getStatistics('month',this.value);">
        <option value="1" <?php if($currentMonth=='1') echo "selected"; ?>>January</option>
        <option value="2" <?php if($currentMonth=='2') echo "selected"; ?>>February</option>
        <option value="3" <?php if($currentMonth=='3') echo "selected"; ?>>March</option>
        <option value="4" <?php if($currentMonth=='4') echo "selected"; ?>>April</option>
        <option value="5" <?php if($currentMonth=='5') echo "selected"; ?>>May</option>
        <option value="6" <?php if($currentMonth=='6') echo "selected"; ?>>June</option>
        <option value="7" <?php if($currentMonth=='7') echo "selected"; ?>>July</option>
        <option value="8" <?php if($currentMonth=='8') echo "selected"; ?>>August</option>
        <option value="9" <?php if($currentMonth=='9') echo "selected"; ?>>September</option>
        <option value="10" <?php if($currentMonth=='10') echo "selected"; ?>>October</option>
        <option value="11" <?php if($currentMonth=='11') echo "selected"; ?>>November</option>
        <option value="12" <?php if($currentMonth=='12') echo "selected"; ?>>December</option>
        </select>
        
        </div>
        </div>
        
        <div class="row reportOptions pt-3" id="date_div" style="display:none">  <div class="col-md-2">  </div>
        <div class="col-md-2">  
        <input type="text" class="form-control datepicker" name="dateField" id="dateField" value="<?php echo date('m/d/Y',time()); ?>"  onchange="getStatistics('date',this.value);">
        </div></div>
        
        <div class="row reportOptions pt-3" id="range_div" style="display:none">  <div class="col-md-2">  </div>
        <div class="col-md-1">  
        <input type="text" class="form-control datepicker" name="from_date" id="from_date" value="<?php echo date('m/d/Y',time()); ?>" ></div>
        <div class="col-md-1">  
        <input type="text" class="form-control datepicker" name="to_date" id="to_date" value="<?php echo date('m/d/Y',time()); ?>" > </div>
        <div class="col-md-1">   <input type="button" class="btn btn-primary" name="Submit" value="Submit" onclick="getStatistics('range','');" /> </div>
        </div>
        
        <div class="row pt-3">
        <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box">
        <div class="bg-icon bg-icon-success pull-left">
            <i class="ti-eye text-success"></i>
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10"><b class="counter" id="total_leads" style="cursor:pointer" onclick="showLeads()"><?=$statArr[0]?></b></h3>
            <p class="text-muted mb-0">Total Leads</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>
        <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box fadeInDown animated">
        <div class="bg-icon bg-icon-primary pull-left">
            <i class=" ti-money text-info"></i>
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10"><b class="counter" style="cursor:pointer" onclick="showRevenue('')" id="revenue"><?=$statArr[2]?></b></h3>
            <p class="text-muted mb-0">Total Revenue</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>
        
        <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box">
        <div class="bg-icon bg-icon-danger pull-left">
            <i class="ti-shopping-cart text-pink"></i>
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10"><b class="counter" style="cursor:pointer" onclick="showInvoices()" id="total_invoice"><?=$statArr[1]?></b></h3>
            <p class="text-muted mb-0">Today's Sales</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>

            <div class="col-lg-4 col-xl-3">
                <div class="widget-bg-color-icon card-box">
                    <div class="bg-icon bg-icon-purple pull-left">
                        <i class="ti-money text-purple"></i>
                    </div>
                    <div class="text-right">
                        <div class="row">
                            <div class="col-lg-6">
                        <h3 class="text-dark m-t-10"><b class="counter" style="cursor:pointer" onclick="showRevenue('new')" id="newsales"><?=$statArr[8]?></b></h3>
                        <p class="text-muted mb-0">New Sales</p>
                                </div>
                            <div class="col-lg-6">
                                <h3 class="text-dark m-t-10"><b class="counter" style="cursor:pointer" onclick="showRevenue('installment')" id="installment"><?=$statArr[9]?></b></h3>
                                <p class="text-muted mb-0">Installment</p>
                            </div>

                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
                </div>


            <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box">
        <div class="bg-icon bg-icon-purple pull-left">
           <i class="ti-stats-up text-purple"></i>
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10"><b class="counter"  id="conversion"><?=$statArr[3]?></b>%</h3>
            <p class="text-muted mb-0">Conversion</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>
        
        
        <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box">
        <div class="bg-icon bg-icon-purple pull-left">
             <i class="fas fa-money-check text-purple"></i> 
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10"><b class="counter"  style="cursor:pointer" onclick="showInstallment()"  id="installments"><?=$statArr[5]?></b></h3>
            <p class="text-muted mb-0">Upcoming Installments</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>
                
        <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box">
        <div class="bg-icon bg-icon-purple pull-left">
             <i class="fas fa-money-check text-purple"></i> 
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10"><b class="counter"  style="cursor:pointer" onclick="showInstallment()"  id="installmentAmount"><?=$statArr[6]?></b></h3>
            <p class="text-muted mb-0">Total Installments</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>
        
        <div class="col-lg-4 col-xl-3">
        <div class="widget-bg-color-icon card-box" style="background-color:red">
        <div class="bg-icon bg-icon-purple pull-left">
             <i class="fas fa-money-check text-purple"></i> 
        </div>
        <div class="text-right">
            <h3 class="text-dark m-t-10" style="color:#fff !important"><b class="counter"  style="cursor:pointer" onclick="showPendingInstallment()"  id="pendingInstallmentAmount"><?=$statArr[7]?></b></h3>
            <p class="text-muted mb-0" style="color:#fff !important">Total Missed Installments</p>
        </div>
        <div class="clearfix"></div>
        </div>
        </div>

        </div>
        
        <div class="row pt-3">
        <div class="col-md-7 bg-white border table_div" id="table_div">
      
        </div>
         <div class="col-md-5 bg-white border"><span class="right_bar_div" id="right_bar_div"> </span>
      
          <span class="library_div"></span> </div>
        </div>        
        <div class="row" style="margin-top:10px">
        <div class="col-lg-8">
        <div class="card" style="padding:10px"><h5 class="card-header bg-primary text-white"> New Questionnaire Comments </h5>
                        
        <button type="button" style="width: 25%;margin-top: 10px;" class="btn btn-info" data-toggle="collapse" data-target="#questionaire_comments">Show/Hide</button>
            <div style="margin-top:10px" id="questionaire_comments" class="collapse">
        <div class="row" style="font-weight:600">
<div class="col-md-1 d-none d-sm-block">#</div>
<div class="col-md-2 d-none d-sm-block">Invoice Id</div>
<div class="col-md-3 d-none d-sm-block">Line Item</div>
<div class="col-md-4 d-none d-sm-block">Document Name</div>
<div class="col-md-2 d-none d-sm-block">Action</div>
</div>
<div class="col-md-12 d-none d-sm-block"><hr></div>
        
          <?php
             $invoiceObj->viewBy='A';
             $unread_comments=$invoiceObj->getUnreadQuestionnaireComments();
            
             if(count($unread_comments) > 0)
             foreach($unread_comments as $key => $val)
             {               

                $param = array('tableName'=>TBL_QUESTIONNAIRE_DTLS,'fields'=>array('document_name'),'orderby'=>'id','sortby'=>'desc','condition'=>array('invoice_line_item_id'=>$val->invoice_line_item_id.'-INT','document_id'=>$val->document_ids.'-IN'),'showSql'=>'N');
                $rscomments= Table::getData($param); 
                
                $docnameStr='<ul style="list-style:none">';
                foreach($rscomments as $mk => $mv)
                {
                    $docnameStr.='<li style="border-bottom: 1px solid #00000026;padding-top: 10px;">'.$mv->document_name.'</li>';
                }
                $docnameStr.='</ul>';
                $bg='';  $i++;   
                if ($i % 2 == 1 && $i != count($unread_comments)) { $bg = ' rgba(0, 0, 0, 0.03)';   }
                 ?>
             <div class="row right_border tb_row" style="background-color:<?php echo $bg; ?>;padding-top:10px; padding-bottom:10px;">
                <div class="col-md-1 d-none d-sm-block"><?php echo $i;?></div>
                <div class="col-md-2">BPE-<?php echo $val->invoice_id;?></div>
                <div class="col-md-3"><?php echo $val->lineitem;?></div>
                <div class="col-md-4"><?php echo $docnameStr;?></div>                
                <div class="col-md-2"><ul style="list-style:none">
                <?php 
                    $docIds=explode(",",$val->document_ids);
                    $docIds=array_unique($docIds);
                    foreach($docIds as $dk => $dm)
                    {
                       ?><li style="width:100%;float:left;border-bottom: 1px solid #00000026;padding-top: 10px;">
                        <a href="javascript:void(0)" onclick="showQuestionnaireCmts(<?php echo $val->invoice_line_item_id; ?>,<?php echo  $dm; ?>)">View</a></li>
                       <?php  
                    }
                ?>
                </ul>
                </div>
                </div>
                 <?php

             }else { ?>
                <div class="col-md-12"> No new comments</div>
                <?php } ?>
                </div>
        </div>
        </div>
        <div class="col-lg-4">
        <div id="dashb_con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			 
			<div class="modal-body" style="padding:0px;">
			<div class="body-div commentBlock" style="padding:15px;">

            </div>
				 </div>
                 <div class="modal-footer">
				<button type="button"  class="btn btn-primary waves-effect" data-dismiss="modal">Close</button>
				 
			</div>
			</div>			
		</div>
	</div>
	</div><!-- /.modal -->
        </div> 
        </div>
       </div> 

<script>
function dash_invoice_paymentDtls(invoicePaymentId,invoice_id) {
	  //paramData = {'act':'show_dash_invoice_payment_details','invoice_id':invoice_id,'invoice_payment_id':invoicePaymentId};
	  paramData = {'act':'show_invoice_payment_details','invoice_id':invoice_id};
	  
          ajax({ 
            a:'invoices',
            b:$.param(paramData),
            c:function(){},
            d:function(data){   
			  $('.right_bar_div').html(data);
			  $('#con-close-modal').modal('show');
			  
            }});	    	  
 }

function showRevenue(rType) {
	var optionName = $('#reportType').val();
	if(optionName=='month') paramData = {'act':'show_revenue','type':optionName,'mn':$('#monthValue option:selected').val(),'rType':rType};
	if(optionName=='date')	paramData = {'act':'show_revenue','type':optionName,'dateField':$('#dateField').val(),'rType':rType};
	if(optionName=='range')	paramData = {'act':'show_revenue','type':optionName,'from_date':$('#from_date').val(),'to_date':$('#to_date').val(),'rType':rType};
	if(optionName=='all')  paramData = {'act':'show_revenue','type':'all','rType':rType};
	ajax({ 
		a:'process',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
			$('#table_div').html(data);	
			$('#right_bar_div').html('');					
		}});	
	}


function send_sms(id) {
	
	paramData = {'client_id':id,'type':'client'};
	ajax({ 
		a:'send_sms',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		
			$('.right_bar_div').html(data);	
		  $('#con-close-modal').modal('show'); 		   
		}});	
}


  function show_invoice_paymentDtls(invoice_id) {
	  paramData = {'act':'show_invoice_payment_details','invoice_id':invoice_id};
          ajax({ 
            a:'invoices',
            b:$.param(paramData),
            c:function(){},
            d:function(data){   
			  $('.right_bar_div').html(data);
			  $('#con-close-modal').modal('show');
			  
            }});	    	  
 }


function showInstallment() {
	var optionName = $('#reportType').val();
	if(optionName=='month') paramData = {'act':'show_installment','type':optionName,'mn':$('#monthValue option:selected').val()};
	if(optionName=='date')	paramData = {'act':'show_installment','type':optionName,'dateField':$('#dateField').val()};
	if(optionName=='range')	paramData = {'act':'show_installment','type':optionName,'from_date':$('#from_date').val(),'to_date':$('#to_date').val()};
	if(optionName=='all')  paramData = {'act':'show_installment','type':'all'};
	ajax({ 
		a:'process',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
            //alert(data);
			$('#table_div').html(data);	
			$('#right_bar_div').html('');					
		}});	
	}

  function showPendingInstallment() {
	paramData = {'act':'show_pending_installment'};
	ajax({ 
		a:'process',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
            //alert(data);
			$('#table_div').html(data);	
			$('#right_bar_div').html('');					
		}});	
  }

function showInvoices() {
	var optionName = $('#reportType').val();
	if(optionName=='month') paramData = {'act':'show_invoices','type':optionName,'mn':$('#monthValue option:selected').val()};
	if(optionName=='date')	paramData = {'act':'show_invoices','type':optionName,'dateField':$('#dateField').val()};
	if(optionName=='range')	paramData = {'act':'show_invoices','type':optionName,'from_date':$('#from_date').val(),'to_date':$('#to_date').val()};
	if(optionName=='all')  paramData = {'act':'show_invoices','type':'all'};
	ajax({ 
		a:'process',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
			$('#table_div').html(data);	
			$('#right_bar_div').html('');					
		}});	
	}



function showLeads() {
	var optionName = $('#reportType').val();
	if(optionName=='month') paramData = {'act':'show_dash_leads','type':optionName,'mn':$('#monthValue option:selected').val()};
	if(optionName=='date')	paramData = {'act':'show_dash_leads','type':optionName,'dateField':$('#dateField').val()};
	if(optionName=='range')	paramData = {'act':'show_dash_leads','type':optionName,'from_date':$('#from_date').val(),'to_date':$('#to_date').val()};
	if(optionName=='all')  paramData = {'act':'show_dash_leads','type':'all'};
	ajax({ 
		a:'process',
		b:$.param(paramData),
		c:function(){},
		d:function(data){		
			$('#table_div').html(data);
			$('#right_bar_div').html('');						
		}});	
	}
	
 

function showOptions(){
	var optionName = $('#reportType').val();
	$('.reportOptions').hide();
	$('#'+optionName+'_div').show();
	
	if(optionName=='month') {
	getStatistics('month',$('#monthValue option:selected').val())	
	}
	if(optionName=='all') {
		getStatistics('all','');
	}
	 }
function getStatistics(type,value) {
    $('#table_div').html('');
	if(type=='month')	paramData = {'act':'get_statistics','type':type,'month':value,'mn':$('#monthValue option:selected').text()};
	if(type=='date')	paramData = {'act':'get_statistics','type':type,'dateField':value};
	if(type=='range')	paramData = {'act':'get_statistics','type':type,'from_date':$('#from_date').val(),'to_date':$('#to_date').val()};
	if(type=='all')  paramData = {'act':'get_statistics'};
	ajax({ 
		a:'process',
		b:$.param(paramData),
		c:function(){},
		d:function(data){
		
			dataArr = data.split('::');
			$('#total_leads').html(dataArr[0]);
			$('#revenue').html(dataArr[2]);
			$('#total_invoice').html(dataArr[1]);
			$('#conversion').html(dataArr[3]);	
			$('#stat_heading').html(dataArr[4]);	
			$('#installments').html(dataArr[5]);	
			$('#installmentAmount').html(dataArr[6]);            
		}});	
 }
 
function showSendEmail(id,email_type,param_type) {

   if(param_type=='I') paramData = {'act':'showSendEmail','invoice_id':id,param_type:param_type,'email_type':email_type};
   if(param_type=='C') paramData = {'act':'showSendEmail','client_id':id,param_type:param_type,'email_type':email_type};
   if(param_type=='IS') paramData = {'act':'showSendEmail','installment_id':id,param_type:param_type,'email_type':email_type};
   if(param_type=='L') paramData = {'act':'showSendEmail','lead_id':id,param_type:param_type,'email_type':email_type};
   if(param_type=='IP') paramData = {'act':'showSendEmail','invoice_payment_id':id,param_type:param_type,'email_type':email_type}; //invoice payment

	ajax({ 
		a:'process',
		b:$.param(paramData), 
		c:function(){},
		d:function(data){ 		
		  $('.right_bar_div').html(data);	
          $('#con-close-modal').modal('show');		  
		}});	
} 
 
function showQuestionnaireCmts(invLineItemId,documentId,questionnaireId) {
	 paramData = {'act':'showQuestionnaireCmts','invoice_line_item_id': invLineItemId,"document_id":documentId,"questionnaire_id":questionnaireId,'dashboard':1};
          ajax({ 
            a:'process',
            b:$.param(paramData),
            c:function(){},
            d:function(data){  
                $('.commentBlock').html(data);	 
                $('#dashb_con-close-modal').modal('show');
                $("html, body").animate({ scrollTop: $("#lastCId").offset().top }, "slow");             
                
            }}); 
}

$(document).on('click', '.datepicker', function(){
   $(this).datepicker({
      changeMonth: true,
      changeYear: true
     }).focus();
   $(this).removeClass('datepicker'); });
</script>                  
       
 <?php } include 'template.php'; ?>
 
  