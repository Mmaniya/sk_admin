<div id="logs_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg" style="max-width:80%; max-height:100%">
        <div class="modal-content">
            <div class="modal-body" style="padding:0px;">
                <div class="body-div" style="padding:15px;">
                    <div class="card">
                        <label class="card-header bg-primary text-white"><?php echo $title;?> Logs <a href="javascript:void(0)" class="text-white float-right" data-dismiss="modal">Close</a></label>
                        <div class="col-md-12">
                            <div class="card-body log_div">

                            </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>