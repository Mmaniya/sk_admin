<?php

//4107212097335918

include "includes.php";

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>BizPlanEasy Payment</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
     <!-- <link href="css/grid.css" rel="stylesheet">-->
  
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.9.0/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.9.0/css/v4-shims.css">
          <script src="js/modernizr.min.js"></script>
		<script src="js/jquery.min.js"></script>
		<script src="js/default.js"></script>
        <script src="js/jquery.inputmask.bundle.js"></script>
		  <link href="css/style.css" rel="stylesheet">	 
      <script type="text/javascript" src="https://seal-newjersey.bbb.org/inc/legacy.js"></script>
  </head>

  
  
  <body class="body-bg">  
 <section style="padding-top:50px;padding-bottom:50px;">
  <div class="container">  
      <div class="container-inner-section"> 
      <div class="row header-row"> 
	    <div class="col-sm-6"><img src="images/logo.png" class="img-fluid logo-img" alt="logo"></div> 
	    <div class="col-sm-6">
          <div class="header-text">		
		      <a href="mailto:support@bizplaneasy.com">support@bizplaneasy.com</a><br/>
              <a href="tel:8775332075">877-533-2075</a>
		  </div>
		</div>
	  </div>
             <?php main();  ?>
         </div>
          </div>
      		  

</section>

    <script src="js/bootstrap.min.js"></script>
  </body>
</html>

  